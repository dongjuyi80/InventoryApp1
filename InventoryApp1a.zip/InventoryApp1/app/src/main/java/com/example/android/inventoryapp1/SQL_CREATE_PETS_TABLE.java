package com.example.android.inventoryapp1;

class SQL_CREATE_PETS_TABLE {
}
