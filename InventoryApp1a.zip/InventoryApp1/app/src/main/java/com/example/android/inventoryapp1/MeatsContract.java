package com.example.android.inventoryapp1;

import android.provider.BaseColumns;



    /**
     * API Contract for the Meats app.
     */
    public final class MeatsContract {

        // To prevent someone from accidentally instantiating the contract class,
        // give it an empty constructor.
        private MeatsContract() {}

        /**
         * Inner class that defines constant values for the meats database inventory table.
         * Each entry in the table represents a single meat.
         */
        public static final class MeatEntry implements BaseColumns {

            /** Name of database table for meats */
            public final static String TABLE_NAME = "meats";

            /**
             * Name of Product.
             *
             * Type: TEXT
             */
            public final static String PRODUCT= "product";

            /**
             * Price
             *
             * Type: Integer
             */
            public final static String COLUMN_PRICE ="price";

            /**
             * Quantity
             *
             * Type: TEXT
             */
            public final static String COLUMN_QUANTITY= "quantity";

            /**
             *
             *
             * Supplier Name
             *
             *
             * Type: TEXT
             */
            public final static String COLUMN_SUPPLIER_NAME = "suppliername";

            /**
             * Phone-number of Supplier
             *
             * Type: TEXT
             */
            public final static String COLUMN_SUPPLIER_PHONE = "supplierphone";


        }

    }


